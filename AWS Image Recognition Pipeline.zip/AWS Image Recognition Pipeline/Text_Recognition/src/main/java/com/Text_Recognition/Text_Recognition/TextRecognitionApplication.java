package com.Text_Recognition.Text_Recognition;

import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.SqsException;

import java.io.*;
import java.util.List;
import java.util.Objects;

@SpringBootApplication
public class TextRecognitionApplication {

	public static void main(String[] args) {

		SpringApplication.run(TextRecognitionApplication.class, args);

		//bucket name
		String AWS_BUCKET = "njit-cs-643";

		//init sqs service
		String queueUrl = "https://sqs.us-east-1.amazonaws.com/929120524533/AWS_Project_SQS.fifo";
		SqsClient sqsClient = SqsClient.create();

		//start goes in EC2_B
		try {

			//init variables and location for output file
			//And it will be stored at ~/output.txt
			String userProfile = System.getProperty("user.home");
			String file_location = userProfile + File.separator + "output.txt";
			FileOutputStream fileOutputStream = new FileOutputStream(file_location, false);

			PrintWriter printWriter = new PrintWriter(fileOutputStream);
			printWriter.println("------------Output------------");
			printWriter.println("Index of Image:          Texts");
			printWriter.println("------------------------------");


			while(true){

				//collect queued objects from sqs
				ReceiveMessageRequest receiveMessageRequest = ReceiveMessageRequest.builder()
						.queueUrl(queueUrl)
						.maxNumberOfMessages(10)
						.build();
				List<Message> messages_list = sqsClient.receiveMessage(receiveMessageRequest).messages();

				//loop through each queued image
				for (Message message : messages_list) {

					if (Objects.equals(message.body(), "-1")) {
						System.out.println("Received -1. Exiting...");
						//deleted -1 from queue
						DeleteMessageRequest deleteMessageRequest = DeleteMessageRequest.builder()
								.queueUrl(queueUrl)
								.receiptHandle(message.receiptHandle())
								.build();
						sqsClient.deleteMessage(deleteMessageRequest);

						//close writer and file
						printWriter.close();
						fileOutputStream.close();

						//exiting the application
						return;
					}
					System.out.println("----------------------------------------");
					System.out.println("Received message: " + message.body());
					String photo = message.body();

					//init AmazonRekognition client
					AmazonRekognition rekognitionClient2 = AmazonRekognitionClientBuilder.defaultClient();

					//use Rekognition service request for text detection
					DetectTextRequest request = new DetectTextRequest()
							.withImage(new Image()
									.withS3Object(new S3Object()
											.withName(photo)
											.withBucket(AWS_BUCKET)));


					try {
						//results from rekognition request
						DetectTextResult result = rekognitionClient2.detectText(request);
						List<TextDetection> textDetections = result.getTextDetections();


						if (textDetections.isEmpty()) {
							System.out.println("No words are found");
							System.out.println("----------------------------------------" + "\n");
						}else {
							System.out.println("--Detected texts for " + photo + "--\n");
							//writing in output file
							printWriter.print(photo + "              ");

							//for loop for text Recognition in the image
							for (TextDetection text: textDetections) {
								System.out.println("    Detected Text: " + text.getDetectedText());
								System.out.println("    Confidence: " + text.getConfidence().toString());
								System.out.println();

								//writing in output file
								printWriter.print("'" + text.getDetectedText() + "', ");
							}
							printWriter.println("");
							System.out.println("----------------------------------------" + "\n");
						}

					//catch for AWS Rekognition service
					} catch(AmazonRekognitionException e) {
						e.printStackTrace();
					}

					//deleted object from queue after processing
					DeleteMessageRequest deleteMessageRequest = DeleteMessageRequest.builder()
							.queueUrl(queueUrl)
							.receiptHandle(message.receiptHandle())
							.build();
					sqsClient.deleteMessage(deleteMessageRequest);
				} //for loop for each queue message

			} // while loop ends



			//catch for aws sqs service
		} catch (SqsException e) {
			System.err.println(e.awsErrorDetails().errorMessage());
			System.exit(1);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	} //main ends

}
