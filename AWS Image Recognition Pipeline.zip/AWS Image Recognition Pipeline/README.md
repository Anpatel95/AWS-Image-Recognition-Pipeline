# AWS-application-project-1
Programming Assignment 1 - Cloud infrastructure and parallel programming

## How to Create AWS EC2 A and EC2 B instances? (Follow below steps to create both instances)

1. Launch AWS Academy Learner Lab from Canvas
2. Click on "AWS" on AWS Academy Learner Lab to open AWS console
3. Click on "Launch Instance"
4. Enter the instance name
5. Select the following settings:
   - Amazon Linux 2023 AMI - Free tier
   - Instance type - t2.micro - Free tier
   - Create a new encrypted RSA key pair to SSH from a local machine and download the .pem key.
6. Network Settings:
   - Allow SSH traffic from My IP
   - Allow HTTPS traffic from the internet
   - Allow HTTP traffic from the internet
7. Configure storage: Default 8GiB gp3
8. Click "Launch Instance"

## How to connect to Instances?

1. Copy AWS Access Key, Secret Access Key, and Session Token to your local machine's "~/.aws/credentials" from AWS Details on AWS Academy Learner Lab.
2. Select the EC2 instance and click on "Connect"
3. Follow the steps on connecting via SSH Client

## How to Install Required Kits and authentication on both Instances?

1. Follow this AWS documentation to install **Amazon Corretto 17 JDK** ([Amazon Corretto 17 Installation Guide](https://docs.aws.amazon.com/corretto/latest/corretto-17-ug/amazon-linux-install.html)).
2. Install **Apache Maven** on your EC2 instances by running the following commands:

   ```bash
   sudo wget https://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo -O /etc/yum.repos.d/epel-apache-maven.repo
   ```
   ```bash
   sudo yum install -y apache-maven
   ```

3. Install **Git** on your EC2 instances by running the following command:

   3.1 Installing Git
   ```bash
   sudo dnf install git -y
   ```
   3.2 Confirm Git version
   ```bash
   git --version
   ```

4. Copy AWS Access Key, Secret Access Key, and Session Token to instances in "~/.aws/credentials" from AWS Details on AWS Academy Learner Lab.

## How to run the application?

### On EC2 B:

1. Clone the project using the following link (private repo, so the developer needs to request access from the author):

   ```bash
   git clone git@github.com:ap2684/AWS-application-project-1.git
   ```

2. Navigate to the directory:

   ```bash
   cd AWS-application-project-1/Text_Recognition/
   ```

3. Clean Build the Text Recognition application using the following command:

   ```bash
   mvn clean install
   ```

4. Run the application:

   ```bash
   java -jar ./target/Text_Recognition-0.0.1-SNAPSHOT.jar
   ```

   (Note: The Text Recognition application continuously reads the SQS queue until EC2 A sends "-1" to signal that there are no more objects, so run the Text Recognition application first)

### On EC2 A:

1. Clone the project using the following link (private repo, so the developer needs to request access from the author):

   ```bash
   git clone git@github.com:ap2684/AWS-application-project-1.git
   ```

2. Navigate to the directory:

   ```bash
   cd AWS-application-project-1/Car_Recognition/
   ```

3. Clean Build the Car Recognition application using the following command:

   ```bash
   mvn clean install
   ```

4. Run the application:

   ```bash
   java -jar ./target/Car_Recognition-0.0.1-SNAPSHOT.jar
   ```

## Where to find output.txt?

To review the output, follow the command:

```bash
vim ~/output.txt
```

## References (AWS Documentation)

 + [Apache Maven](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/setup-project-maven.html)
 + [AWS S3](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/examples-s3-buckets.html)
 + [AWS SQS](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/examples-sqs-messages.html)
 + [AWS Rekognition](https://docs.aws.amazon.com/rekognition/latest/dg/labels-detect-labels-image.html)