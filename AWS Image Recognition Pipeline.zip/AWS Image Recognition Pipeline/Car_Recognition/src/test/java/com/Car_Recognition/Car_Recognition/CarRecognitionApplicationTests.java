package com.Car_Recognition.Car_Recognition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRecognitionApplicationTests {

	@Test
	void contextLoads() {
	}

}
