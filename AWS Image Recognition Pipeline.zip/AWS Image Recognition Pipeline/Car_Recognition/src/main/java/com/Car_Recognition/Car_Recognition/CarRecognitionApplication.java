package com.Car_Recognition.Car_Recognition;

import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

import java.util.List;
import java.util.Objects;

@SpringBootApplication
public class CarRecognitionApplication {

	public static void main(String[] args) {

		SpringApplication.run(CarRecognitionApplication.class, args);
		//bucket name
		String AWS_BUCKET = "njit-cs-643";

		//init S3 service
		AmazonS3 s3Client2 = AmazonS3ClientBuilder.defaultClient();

		//init sqs service
		String queueUrl = "https://sqs.us-east-1.amazonaws.com/929120524533/AWS_Project_SQS.fifo";
		try (SqsClient sqsClient = SqsClient.create()) {

			//get list of all S3Object stored in the bucket
			List<S3ObjectSummary> objectSummaries = s3Client2.listObjects(AWS_BUCKET).getObjectSummaries();

			//loop through each picture to recognize objects
			for (S3ObjectSummary object : objectSummaries) {

				//picture from S3 bucket
				String photo = object.getKey();
				AmazonRekognition rekognitionClient = AmazonRekognitionClientBuilder.defaultClient();

				//request to rekognition
				DetectLabelsRequest request = new DetectLabelsRequest()
						.withImage(new Image().withS3Object(new S3Object().withName(photo).withBucket(AWS_BUCKET)))
						.withMaxLabels(10).withMinConfidence(90F);

				try {
					//computed results from AWS Rekognition
					DetectLabelsResult result = rekognitionClient.detectLabels(request);

					// list of label detected in an image
					List<Label> labels = result.getLabels();

					//detected label in the image with confidence
					for (Label label : labels) {
						//loop to check if car is found in the image and its confidence is over 90%
						if (Objects.equals(label.getName(), "Car") && label.getConfidence() > 90.0) {
							System.out.println("--------------------");
							System.out.println("Object Key: " + object.getKey());
							System.out.println("Car label found in " + photo + " with over 90% confidence" + "\n");
							System.out.println("Label: " + label.getName());
							System.out.println("Confidence: " + label.getConfidence());
							System.out.println("--------------------" + "\n");

							//Queue detected car image index for EC2 B
							String uniqueDeduplicationId = "UniqueId" + System.currentTimeMillis();
							sqsClient.sendMessage(SendMessageRequest.builder()
									.queueUrl(queueUrl)
									.messageBody(object.getKey())
									.messageGroupId("MyQueue")
									.messageDeduplicationId(uniqueDeduplicationId)
									.build());
							break;
						}
					}

				} catch (AmazonRekognitionException e) {
					e.printStackTrace();
				}
			}//for loop ends - S3 objects

			//adds -1 index to the queue to signal instance B that no more indexes will come
			String uniqueDeduplicationId = "UniqueId" + System.currentTimeMillis();
			sqsClient.sendMessage(SendMessageRequest.builder()
					.queueUrl(queueUrl)
					.messageBody("-1")
					.messageGroupId("MyQueue")
					.messageDeduplicationId(uniqueDeduplicationId)
					.build());
		}catch (AwsServiceException e) {
			e.printStackTrace();
		}


	}//main ends

}
